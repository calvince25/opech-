/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { BlogPost } from '../types';
import { Loader2 } from 'lucide-react';

interface JournalProps {
  onArticleClick: (article: BlogPost) => void;
  fullPage?: boolean;
}

const Journal: React.FC<JournalProps> = ({ onArticleClick, fullPage = false }) => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPosts() {
      let query = supabase
        .from('blog_posts')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!fullPage) {
        query = query.limit(3);
      }
      
      const { data } = await query;
      
      if (data) setPosts(data);
      setLoading(false);
    }
    fetchPosts();
  }, [fullPage]);

  return (
    <section id="journal" className={`${fullPage ? 'pt-32' : 'py-32'} bg-[#F5F2EB] px-6 md:px-12`}>
      <div className="max-w-[1800px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-20 pb-8 border-b border-[#D6D1C7]">
            <div>
                <span className="block text-xs font-bold uppercase tracking-[0.2em] text-[#A8A29E] mb-4">Editorial</span>
                <h2 className="text-4xl md:text-6xl font-serif text-[#2C2A26]">{fullPage ? 'The Blog' : 'The Journal'}</h2>
            </div>
            {!fullPage && (
              <p className="text-[#5D5A53] font-light max-w-sm mt-4 md:mt-0">
                Stories of craftsmanship, heritage, and the vibrant spirit of Nairobi.
              </p>
            )}
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-[#2C2A26]" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {posts.length === 0 ? (
                <div className="col-span-full text-center py-10 opacity-50">
                  <p className="text-xl font-serif">No stories published yet.</p>
                </div>
              ) : (
                posts.map((article) => (
                    <div key={article.id} className="group cursor-pointer flex flex-col text-left" onClick={() => onArticleClick(article)}>
                        <div className="w-full aspect-[4/3] overflow-hidden mb-8 bg-[#EBE7DE]">
                            <img 
                                src={article.image_url} 
                                alt={article.title} 
                                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 grayscale-[0.2] group-hover:grayscale-0"
                            />
                        </div>
                        <div className="flex flex-col flex-1 text-left">
                            <span className="text-xs font-medium uppercase tracking-widest text-[#A8A29E] mb-3">
                              {new Date(article.created_at).toLocaleDateString()}
                            </span>
                            <h3 className="text-2xl font-serif text-[#2C2A26] mb-4 leading-tight group-hover:underline decoration-1 underline-offset-4">{article.title}</h3>
                            <p className="text-[#5D5A53] font-light leading-relaxed line-clamp-2">{article.excerpt}</p>
                        </div>
                    </div>
                ))
              )}
          </div>
        )}
      </div>
    </section>
  );
};

export default Journal;
