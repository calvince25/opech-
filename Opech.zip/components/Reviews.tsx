import React, { useEffect, useState } from 'react';
import { Star, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Review } from '../types';

interface ReviewsProps {
  fullPage?: boolean;
}

export default function Reviews({ fullPage = false }: ReviewsProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReviews = async () => {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('status', 'published')
        .order('created_at', { ascending: false });
      
      if (!error && data) {
        setReviews(data);
      }
      setLoading(false);
    };

    fetchReviews();
  }, []);

  if (loading) {
    return (
      <div className="py-20 flex justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-stone-900" />
      </div>
    );
  }

  return (
    <div className={`${fullPage ? 'pt-32 pb-24 px-6 max-w-[1800px] mx-auto' : 'mt-20 border-t border-stone-200 pt-16'}`}>
      <div className="flex items-center justify-between mb-12">
        <h2 className={`${fullPage ? 'text-4xl md:text-5xl font-serif' : 'text-3xl font-serif'}`}>Customer Reviews</h2>
        <div className="flex items-center gap-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-stone-800 text-stone-800" />
            ))}
          </div>
          <span className="font-medium">4.9 out of 5</span>
        </div>
      </div>

      {reviews.length === 0 ? (
        <div className="text-center py-12 text-stone-500 italic">
          No reviews yet. Be the first to share your experience!
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <div key={review.id} className="bg-white p-8 rounded-2xl border border-stone-100 shadow-sm">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < review.rating ? 'fill-stone-800 text-stone-800' : 'text-stone-200'}`} 
                  />
                ))}
              </div>
              <p className="text-stone-700 mb-6 italic leading-relaxed">"{review.comment}"</p>
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm">{review.customer_name}</span>
                <span className="text-stone-400 text-xs">{new Date(review.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
