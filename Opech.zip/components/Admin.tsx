import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { LayoutDashboard, ShoppingBag, Users, Settings, Plus, Search, MoreVertical, TrendingUp, Package, DollarSign, Star, FileText, Check, X, Loader2, Mail, Trash2, Edit2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Profile, BlogPost, Review, ContactMessage, Product } from '../types';

export default function Admin() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [profilesRes, blogRes, productsRes, reviewsRes, messagesRes] = await Promise.all([
        supabase.from('profiles').select('*').order('created_at', { ascending: false }),
        supabase.from('blog_posts').select('*').order('created_at', { ascending: false }),
        supabase.from('products').select('*').order('created_at', { ascending: false }),
        supabase.from('reviews').select('*').order('created_at', { ascending: false }),
        supabase.from('contact_messages').select('*').order('created_at', { ascending: false })
      ]);

      if (profilesRes.data) setProfiles(profilesRes.data);
      if (blogRes.data) setBlogPosts(blogRes.data);
      if (productsRes.data) setProducts(productsRes.data);
      if (reviewsRes.data) setReviews(reviewsRes.data);
      if (messagesRes.data) setMessages(messagesRes.data);
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handlers for Users
  const handleApproveUser = async (userId: string, approved: boolean) => {
    setActionLoading(userId);
    const { error } = await supabase
      .from('profiles')
      .update({ is_approved: approved })
      .eq('id', userId);
    
    if (!error) {
      setProfiles(profiles.map(p => p.id === userId ? { ...p, is_approved: approved } : p));
    }
    setActionLoading(null);
  };

  // Handlers for Blog
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [newPost, setNewPost] = useState({ title: '', excerpt: '', content: '', image_url: '' });

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading('create-post');
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      const { error } = await supabase
        .from('blog_posts')
        .insert({
          ...newPost,
          author_id: user.id,
          author_name: 'Mell Bags Admin'
        });
      
      if (!error) {
        setShowCreatePost(false);
        setNewPost({ title: '', excerpt: '', content: '', image_url: '' });
        fetchData();
      }
    }
    setActionLoading(null);
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return;
    setActionLoading(postId);
    const { error } = await supabase.from('blog_posts').delete().eq('id', postId);
    if (!error) setBlogPosts(blogPosts.filter(p => p.id !== postId));
    setActionLoading(null);
  };

  // Handlers for Products
  const [showCreateProduct, setShowCreateProduct] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '', tagline: '', description: '', longDescription: '', price: 0, category: 'Clutches' as any, imageUrl: '', gallery: [], features: []
  });

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading('create-product');
    const { error } = await supabase.from('products').insert(newProduct);
    if (!error) {
      setShowCreateProduct(false);
      setNewProduct({ name: '', tagline: '', description: '', longDescription: '', price: 0, category: 'Clutches' as any, imageUrl: '', gallery: [], features: [] });
      fetchData();
    }
    setActionLoading(null);
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    setActionLoading(productId);
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (!error) setProducts(products.filter(p => p.id !== productId));
    setActionLoading(null);
  };

  // Handlers for Reviews
  const handleToggleReviewStatus = async (reviewId: string, currentStatus: string) => {
    setActionLoading(reviewId);
    const newStatus = currentStatus === 'published' ? 'pending' : 'published';
    const { error } = await supabase.from('reviews').update({ status: newStatus }).eq('id', reviewId);
    if (!error) {
      setReviews(reviews.map(r => r.id === reviewId ? { ...r, status: newStatus as any } : r));
    }
    setActionLoading(null);
  };

  const handleDeleteReview = async (reviewId: string) => {
    if (!confirm('Are you sure you want to delete this review?')) return;
    setActionLoading(reviewId);
    const { error } = await supabase.from('reviews').delete().eq('id', reviewId);
    if (!error) setReviews(reviews.filter(r => r.id !== reviewId));
    setActionLoading(null);
  };

  // Handlers for Messages
  const handleMarkMessageRead = async (messageId: string) => {
    setActionLoading(messageId);
    const { error } = await supabase.from('contact_messages').update({ status: 'read' }).eq('id', messageId);
    if (!error) {
      setMessages(messages.map(m => m.id === messageId ? { ...m, status: 'read' } : m));
    }
    setActionLoading(null);
  };

  const stats = [
    { label: 'Total Sales', value: 'KES 142,500', icon: DollarSign, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Orders', value: '24', icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Products', value: products.length.toString(), icon: Package, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Customers', value: profiles.length.toString(), icon: Users, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  if (loading) {
    return (
      <div className="pt-32 flex items-center justify-center min-h-screen bg-stone-50">
        <Loader2 className="w-8 h-8 animate-spin text-stone-900" />
      </div>
    );
  }

  return (
    <div className="pt-24 min-h-screen bg-stone-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-stone-200 hidden md:block">
        <div className="p-6">
          <h2 className="text-xl font-serif font-bold">Mell Admin</h2>
        </div>
        <nav className="mt-4 space-y-1 px-4">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'products', label: 'Products', icon: Package },
            { id: 'blog', label: 'Blog Posts', icon: FileText },
            { id: 'reviews', label: 'Reviews', icon: Star },
            { id: 'messages', label: 'Messages', icon: Mail },
            { id: 'customers', label: 'User Approval', icon: Users },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.id 
                  ? 'bg-stone-900 text-white' 
                  : 'text-stone-600 hover:bg-stone-100'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <header className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-serif font-bold capitalize">{activeTab.replace('_', ' ')}</h1>
            <p className="text-stone-500 text-sm">Manage your store operations</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input 
                type="text" 
                placeholder="Search..." 
                className="pl-10 pr-4 py-2 bg-white border border-stone-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-stone-200 w-64"
              />
            </div>
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-2 ${stat.bg} ${stat.color} rounded-lg`}>
                      <stat.icon className="w-5 h-5" />
                    </div>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <p className="text-stone-500 text-sm font-medium">{stat.label}</p>
                  <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-100 flex items-center justify-between">
                <h3 className="font-serif font-bold">Recent Orders</h3>
                <button className="text-stone-500 text-sm hover:text-stone-800">View All</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-stone-50 text-stone-500 font-medium">
                    <tr>
                      <th className="px-6 py-4">Order ID</th>
                      <th className="px-6 py-4">Customer</th>
                      <th className="px-6 py-4">Product</th>
                      <th className="px-6 py-4">Amount</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {[
                      { id: '#ORD-7281', customer: 'Sarah Kamau', product: 'Nairobi NightClutch', amount: 'KES 4,500', status: 'Delivered' },
                      { id: '#ORD-7282', customer: 'Jane Doe', product: 'Savannah Tote', amount: 'KES 6,800', status: 'Processing' },
                      { id: '#ORD-7283', customer: 'Mary Wanjiku', product: 'Kilimani Crossbody', amount: 'KES 3,200', status: 'Shipped' },
                    ].map((order) => (
                      <tr key={order.id} className="hover:bg-stone-50 transition-colors">
                        <td className="px-6 py-4 font-medium">{order.id}</td>
                        <td className="px-6 py-4">{order.customer}</td>
                        <td className="px-6 py-4">{order.product}</td>
                        <td className="px-6 py-4">{order.amount}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            order.status === 'Delivered' ? 'bg-green-100 text-green-700' :
                            order.status === 'Processing' ? 'bg-blue-100 text-blue-700' :
                            'bg-orange-100 text-orange-700'
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-stone-400 hover:text-stone-600">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-6">
            {showCreateProduct ? (
              <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-xl font-serif font-bold">Add New Product</h3>
                  <button onClick={() => setShowCreateProduct(false)} className="text-stone-400 hover:text-stone-600">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <form onSubmit={handleCreateProduct} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Product Name</label>
                      <input 
                        required
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                        placeholder="e.g. Nairobi NightClutch"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Price (KES)</label>
                      <input 
                        required
                        type="number"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Category</label>
                      <select 
                        value={newProduct.category}
                        onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value as any })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                      >
                        <option value="Clutches">Clutches</option>
                        <option value="Totes">Totes</option>
                        <option value="Crossbody">Crossbody</option>
                        <option value="Bucket">Bucket</option>
                        <option value="Weekender">Weekender</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Main Image URL</label>
                      <input 
                        required
                        value={newProduct.imageUrl}
                        onChange={(e) => setNewProduct({ ...newProduct, imageUrl: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                        placeholder="https://images.unsplash.com/..."
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest">Tagline</label>
                    <input 
                      required
                      value={newProduct.tagline}
                      onChange={(e) => setNewProduct({ ...newProduct, tagline: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                      placeholder="e.g. Elegance in the city."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest">Description</label>
                    <textarea 
                      required
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none h-20"
                    />
                  </div>
                  <div className="flex justify-end gap-4">
                    <button type="button" onClick={() => setShowCreateProduct(false)} className="px-6 py-3 text-sm font-bold uppercase tracking-widest text-stone-500">Cancel</button>
                    <button type="submit" disabled={actionLoading === 'create-product'} className="px-8 py-3 bg-stone-900 text-white rounded-lg text-sm font-bold uppercase tracking-widest hover:bg-stone-800 transition-colors disabled:opacity-50 flex items-center gap-2">
                      {actionLoading === 'create-product' ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add Product'}
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-stone-100 flex items-center justify-between">
                  <h3 className="font-serif font-bold">Product Inventory</h3>
                  <button onClick={() => setShowCreateProduct(true)} className="text-stone-900 text-sm font-bold flex items-center gap-2 hover:opacity-70 transition-opacity">
                    <Plus className="w-4 h-4" /> Add Product
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-stone-50 text-stone-500 font-medium">
                      <tr>
                        <th className="px-6 py-4">Product</th>
                        <th className="px-6 py-4">Category</th>
                        <th className="px-6 py-4">Price</th>
                        <th className="px-6 py-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {products.map((product) => (
                        <tr key={product.id} className="hover:bg-stone-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <img src={product.imageUrl} className="w-10 h-10 object-cover rounded" />
                              <span className="font-medium">{product.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">{product.category}</td>
                          <td className="px-6 py-4">KES {product.price.toLocaleString()}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <button className="text-stone-400 hover:text-stone-600"><Edit2 className="w-4 h-4" /></button>
                              <button onClick={() => handleDeleteProduct(product.id)} className="text-red-400 hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'blog' && (
          <div className="space-y-6">
            {showCreatePost ? (
              <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-xl font-serif font-bold">Create New Story</h3>
                  <button onClick={() => setShowCreatePost(false)} className="text-stone-400 hover:text-stone-600">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <form onSubmit={handleCreatePost} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Title</label>
                      <input 
                        required
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                        placeholder="e.g. The Art of Leather Craft"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest">Image URL</label>
                      <input 
                        required
                        value={newPost.image_url}
                        onChange={(e) => setNewPost({ ...newPost, image_url: e.target.value })}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none"
                        placeholder="https://images.unsplash.com/..."
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest">Excerpt</label>
                    <textarea 
                      required
                      value={newPost.excerpt}
                      onChange={(e) => setNewPost({ ...newPost, excerpt: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none h-20"
                      placeholder="A short summary of the story..."
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest">Content</label>
                    <textarea 
                      required
                      value={newPost.content}
                      onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 rounded-lg focus:ring-2 focus:ring-stone-900 outline-none h-64"
                      placeholder="Write your story here..."
                    />
                  </div>
                  <div className="flex justify-end gap-4">
                    <button type="button" onClick={() => setShowCreatePost(false)} className="px-6 py-3 text-sm font-bold uppercase tracking-widest text-stone-500">Cancel</button>
                    <button type="submit" disabled={actionLoading === 'create-post'} className="px-8 py-3 bg-stone-900 text-white rounded-lg text-sm font-bold uppercase tracking-widest hover:bg-stone-800 transition-colors disabled:opacity-50 flex items-center gap-2">
                      {actionLoading === 'create-post' ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Publish Story'}
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-stone-100 flex items-center justify-between">
                  <h3 className="font-serif font-bold">Blog Management</h3>
                  <button onClick={() => setShowCreatePost(true)} className="text-stone-900 text-sm font-bold flex items-center gap-2 hover:opacity-70 transition-opacity">
                    <Plus className="w-4 h-4" /> Create Post
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-stone-50 text-stone-500 font-medium">
                      <tr>
                        <th className="px-6 py-4">Title</th>
                        <th className="px-6 py-4">Date</th>
                        <th className="px-6 py-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {blogPosts.map((post) => (
                        <tr key={post.id} className="hover:bg-stone-50 transition-colors">
                          <td className="px-6 py-4 font-medium">{post.title}</td>
                          <td className="px-6 py-4">{new Date(post.created_at).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <button onClick={() => handleDeletePost(post.id)} disabled={actionLoading === post.id} className="text-red-400 hover:text-red-600 disabled:opacity-50">
                                {actionLoading === post.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100">
              <h3 className="font-serif font-bold">Customer Reviews</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-stone-500 font-medium">
                  <tr>
                    <th className="px-6 py-4">Customer</th>
                    <th className="px-6 py-4">Rating</th>
                    <th className="px-6 py-4">Comment</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {reviews.map((review) => (
                    <tr key={review.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-6 py-4 font-medium">{review.customer_name}</td>
                      <td className="px-6 py-4">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-stone-800 text-stone-800' : 'text-stone-200'}`} />
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-stone-500 max-w-xs truncate">{review.comment}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          review.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {review.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button onClick={() => handleToggleReviewStatus(review.id, review.status)} className="p-2 bg-stone-50 rounded-lg hover:bg-stone-100">
                            {review.status === 'published' ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                          </button>
                          <button onClick={() => handleDeleteReview(review.id)} className="p-2 text-red-400 hover:text-red-600">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100">
              <h3 className="font-serif font-bold">Contact Messages</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-stone-500 font-medium">
                  <tr>
                    <th className="px-6 py-4">From</th>
                    <th className="px-6 py-4">Subject</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {messages.map((msg) => (
                    <tr key={msg.id} className={`hover:bg-stone-50 transition-colors ${msg.status === 'unread' ? 'bg-stone-50/50 font-medium' : ''}`}>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span>{msg.name}</span>
                          <span className="text-xs text-stone-400">{msg.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">{msg.subject}</td>
                      <td className="px-6 py-4">{new Date(msg.created_at).toLocaleDateString()}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          msg.status === 'unread' ? 'bg-blue-100 text-blue-700' : 'bg-stone-100 text-stone-500'
                        }`}>
                          {msg.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button onClick={() => handleMarkMessageRead(msg.id)} disabled={msg.status === 'read'} className="text-stone-400 hover:text-stone-600 disabled:opacity-30">
                          <Check className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'customers' && (
          <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100">
              <h3 className="font-serif font-bold">User Approvals</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-stone-50 text-stone-500 font-medium">
                  <tr>
                    <th className="px-6 py-4">Email</th>
                    <th className="px-6 py-4">Role</th>
                    <th className="px-6 py-4">Joined</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {profiles.map((p) => (
                    <tr key={p.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-6 py-4 font-medium">{p.email}</td>
                      <td className="px-6 py-4 capitalize">{p.role}</td>
                      <td className="px-6 py-4">{new Date(p.created_at).toLocaleDateString()}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          p.is_approved ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {p.is_approved ? 'Approved' : 'Pending'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          {!p.is_approved ? (
                            <button 
                              onClick={() => handleApproveUser(p.id, true)}
                              disabled={actionLoading === p.id}
                              className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors disabled:opacity-50"
                              title="Approve"
                            >
                              {actionLoading === p.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                            </button>
                          ) : (
                            <button 
                              onClick={() => handleApproveUser(p.id, false)}
                              disabled={actionLoading === p.id || p.role === 'admin'}
                              className="p-2 bg-amber-50 text-amber-600 rounded-lg hover:bg-amber-100 transition-colors disabled:opacity-50"
                              title="Revoke Approval"
                            >
                              {actionLoading === p.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <X className="w-4 h-4" />}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-12 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mb-6">
              <Settings className="w-8 h-8 text-stone-400" />
            </div>
            <h3 className="text-xl font-serif font-bold mb-2">Store Settings</h3>
            <p className="text-stone-500 max-w-md">
              Configure your store details, payment gateways, and notification preferences.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
